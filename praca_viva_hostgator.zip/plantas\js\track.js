// URL DA SUA API
// Usando o caminho relativo, ele funciona automaticamente na Vercel, Localhost ou HostGator!
const API_URL = "/backend/api.php";

window.addEventListener("DOMContentLoaded", () => {
    // Pega o nome do arquivo atual (ex: "01_boldo.html" vira "01_boldo")
    let urlPath = window.location.pathname;
    let filename = urlPath.substring(urlPath.lastIndexOf('/') + 1);
    let plantaId = filename.replace('.html', '');

    if (!plantaId) plantaId = "desconhecida";

    fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            acao: "registrar_visualizacao",
            planta_id: plantaId
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Métrica registrada:", data);
    })
    .catch(error => {
        console.error("Erro ao conectar com o banco de dados:", error);
    });
});
